package GUI;

public class GUI implements Runnable {

	public GUI(String string) {
		// TODO Auto-generated constructor stub
	}

}
