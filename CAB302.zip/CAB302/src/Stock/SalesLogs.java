package Stock;

public class SalesLogs {

}
