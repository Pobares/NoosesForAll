package Delivery;

import Store.SuperMart;


/**
 * A Class that takes the array that store all data from the .csv file and determines which items are required to be restocked 
 * and how is needed to be purchased and it cost.
 * 
 * 
 * @author Callum Miller
 *
 */
public class StockOrders {

	public static double[] stockOrder(){
		int reOrderAmount;
		int costPerItem;
		int totalCost;
		double[] data = new double[SuperMart.Items.size()];
		
		for(int i = 0; i < SuperMart.Items.size(); i++) {
			
			if(SuperMart.Items.get(i).getReOrderPoint() > SuperMart.Items.get(i).getStock()){
				reOrderAmount = SuperMart.Items.get(i).getReOrderAmount();
				costPerItem = SuperMart.Items.get(i).getManufatoringCost();
				totalCost = reOrderAmount * costPerItem;
				data[i] = totalCost;
				
				
			}
		
		}
		
		
		return data;

		
	}


}


