import javax.swing.SwingUtilities;

import GUI.GUI;

public class Main {
	public  Main(){
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new GUI("SuperMart"));
	}

}
