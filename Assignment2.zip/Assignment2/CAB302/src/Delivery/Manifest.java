package Delivery;

import java.util.ArrayList;


public class Manifest {

	public static ArrayList<Trucks> Trucks;
	public static void truckManifest(Trucks truck){
		Trucks = new ArrayList<Trucks>();
		Trucks.add(truck);
		
	}
	
}
