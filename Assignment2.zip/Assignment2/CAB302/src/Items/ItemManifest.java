package Items;

import java.util.ArrayList;

/**
 * 
 * @author Dylan Vardanega
 *
 */

public class ItemManifest {

	public static ArrayList<Items> Items;
	public static void itemManifest(Items item){
		Items = new ArrayList<Items>();
		Items.add(item);
		
		
	}
}
